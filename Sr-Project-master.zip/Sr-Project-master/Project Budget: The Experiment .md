## Project Budget: The Experiment
This is the budget for the equipment used to perform our experiment. 

![image](https://user-images.githubusercontent.com/54961082/115455300-a21fd300-a1d6-11eb-9abd-d118c85b404d.png)

