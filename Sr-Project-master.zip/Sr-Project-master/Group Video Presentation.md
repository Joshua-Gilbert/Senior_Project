# The Cheap, Easy, and Mobile Raspberry Pi Hacker!
### Video Link
https://youtu.be/SBUqIPhETqw
### About
This is the Saint Martin's University 2021 senior project presentation for the "Mobile Raspberry Pi Hacker" project.
#### Team Members:
Mitchell "Mitch" Wommack, Jason Nguyen, Joshua Gilbert, and Gary Choi
#### Faculty Professor: 
Dr.Harold Nelson
#### Sponsor: 
Peter Truax
#### Run Time: 
13:29
