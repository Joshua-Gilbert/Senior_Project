# Actions Log Snippet
This image is a snippet of our log used to track all of the actions taken during our experiment. Due to the overall size of the file and the personal network contained within it, the log will not be made public. However, we felt it was important to illustrate how we tracked what was done throughout our experiment. 
![image](https://user-images.githubusercontent.com/54961082/115452156-ec9f5080-a1d2-11eb-8d25-a5b1edf5c05e.png)
